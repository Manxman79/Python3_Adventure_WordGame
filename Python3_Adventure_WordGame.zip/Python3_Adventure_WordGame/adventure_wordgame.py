import time


def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(3)


def intro():
    print_pause("You find yourself standing in an open field, filled with grass and yellow wildflowers."
    "Rumor has it that a wicked fairie is somewhere around here, and has been terrifying the nearby village.")
    print_pause("In front of you is a house.")
    print_pause("To your right is a dark cave.")
    print_pause("In your hand you hold your trusty (but not very effective) dagger.")





def knock_door(items):
    if "answer" == '1':
        print_pause("You approach the door of the house.")
        print_pause("You are about to knock when the door opens and out steps a wicked fairie."
        "Eep! This is the wicked fairie's house!"
        "The wicked fairie attacks you!"
        "You feel a bit under-prepared for this, what with only having a tiny dagger.")

    else:
        print_pause("You approach the door of the house.")
        print_pause("You are about to knock when the door opens and out steps a wicked fairie."
        "Eep! This is the wicked fairie's house!"
        "The wicked fairie attacks you!"
        "You feel a bit under-prepared for this, what with only having a tiny dagger.")
        items.append("1")
    print_pause("Would you like to (1) fight or (2) run away?")
    find_adventure(items)


#def peer_cave(items):
    print_pause("You push the button for the second floor.")
    print_pause("After a few moments, you find yourself "
                "in the human resources department.")
    if "handbook" in items:
        print_pause("The HR folks are busy at their desks.")
        print_pause("There doesn't seem to be much to do here.")
    else:
        print_pause("The head of HR greets you.")
        if "ID card" in items:
            print_pause("He looks at your ID card and then "
                        "gives you a copy of the employee handbook.")
            items.append("handbook")
        else:
            print_pause("He has something for you, but says he can't "
                        "give it to you until you go get your ID card.")
    print_pause("You head back to the elevator.")
    find_adventure(items)


#def third_floor(items):
    print_pause("You push the button for the third floor.")
    print_pause("After a few moments, you find yourself "
                "in the engineering department.")
    print_pause("This is where you work!")
    if "ID card" in items:
        print_pause("You use your ID card to open the door.")
        print_pause("Your program manager greets you and tells "
                    "you that you need to have a copy of the "
                    "employee handbook in order to start work.")
        if "handbook" in items:
            print_pause("Fortunately, you got that from HR!")
            print_pause("Congratulatons! You are ready to start your new job "
                        "as vice president of engineering!")
        else:
            print_pause("They scowl when they see that you don't have it, "
                        "and send you back to the elevator.")
            ride_elevator(items)
    else:
        print_pause("Unfortunately, the door is locked "
                    "and you can't get in.")
        print_pause("It looks like you need some kind of "
                    "key card to open the door.")
        print_pause("You head back to the elevator.")
        find_adventure(items)


def find_adventure(items):
    print_pause("Enter 1 to knock on the door of the house."
                "Enter 2 to peer into the cave.")
    print_pause("What would you like to do?")
    print_pause("Please enter 1 or 2.")

    answer = input()
    if answer == '1':
        knock_door(items)
    elif answer == '2':
        peer_cave(items)
    #elif floor == '3':
    #    third_floor(items)


def play_game():
    items = []
    intro()
    find_adventure(items)


play_game()
